const { ObjectId } = require('mongodb');
const { bookingHoldExpired } = require('../analytics/holdEvents');
const notices = require('../services/bookingNotices');
const { generateUniqueReferenceCode, refOrIdFilter } = require('../utils/refCode');
const { BD_PHONE } = require('../utils/contactValidation');
const { sendList } = require('../utils/pagination');
const { COUPON_CODE, normalizeCode, couponDiscount, couponProblem } = require('../utils/coupons');

// Share of the total paid online to hold the booking; the rest is paid on arrival.
const ADVANCE_RATE = 0.4;
const MAX_TICKETS = 10;
// How long an unpaid booking holds its seats before the sweep releases them.
const HOLD_MINUTES = Number(process.env.BOOKING_HOLD_MINUTES) > 0 ? Number(process.env.BOOKING_HOLD_MINUTES) : 60;
// Limits on unpaid pending bookings, so seats cannot be hoarded without paying.
const MAX_UNPAID_PER_PLAN = 1;
const MAX_UNPAID_TOTAL = 3;

const GENDERS = ['male', 'female', 'other'];
const RELATIONS = ['self', 'spouse', 'parent', 'child', 'sibling', 'relative', 'friend', 'colleague', 'other'];
const PAYMENT_STATUSES = ['unpaid', 'pending_verification', 'advance_paid', 'paid_full', 'failed'];
const BOOKING_STATUSES = ['pending', 'confirmed', 'cancelled', 'completed'];

const TRX_ID = /^[A-Z0-9]{6,30}$/;

// Strict ObjectId check: rejects 12-char strings that isValid() alone would accept.
const toObjectId = (id) => (typeof id === 'string' && ObjectId.isValid(id) && String(new ObjectId(id)) === id ? new ObjectId(id) : null);

const BOOKING_SEARCH_FIELDS = [
  'referenceCode', 'userName', 'userEmail', 'planTitle_en', 'planTitle_bn', 'travellers.phone', 'payment.transactionId',
];

const invalidId = (res) => res.status(400).json({ success: false, message: 'Invalid id' });

const historyEntry = (status, note) => ({ status, note: note || '', date: new Date().toISOString() });

// Returns { travellers } on success or { error } describing the first invalid field.
const validateTravellers = (travellers, count) => {
  if (!Array.isArray(travellers) || travellers.length !== count) {
    return { error: 'Traveller details must be filled in for every ticket' };
  }
  const cleaned = [];
  for (let i = 0; i < travellers.length; i++) {
    const t = travellers[i] || {};
    const label = `Traveller ${i + 1}`;
    const name = String(t.name || '').trim();
    const phone = String(t.phone || '').replace(/[\s-]/g, '');
    const age = Number(t.age);
    if (!name || name.length > 100) return { error: `${label}: name is required` };
    if (!GENDERS.includes(t.gender)) return { error: `${label}: select a gender` };
    if (!BD_PHONE.test(phone)) return { error: `${label}: enter a valid Bangladeshi phone number` };
    if (!Number.isInteger(age) || age < 0 || age > 120) return { error: `${label}: enter a valid age` };
    if (!RELATIONS.includes(t.relation)) return { error: `${label}: select a relation` };
    cleaned.push({ name, gender: t.gender, phone, age, relation: t.relation });
  }
  return { travellers: cleaned };
};

// Today's date (YYYY-MM-DD) in Bangladesh, where all trips take place.
const DHAKA_OFFSET_MS = 6 * 60 * 60 * 1000;
const todayInDhaka = () => new Date(Date.now() + DHAKA_OFFSET_MS).toISOString().slice(0, 10);

// A trip whose start date is before today has already started. Plans without
// a usable YYYY-MM-DD start date are not restricted.
const hasStarted = (plan) => {
  const start = typeof plan.start_date === 'string' ? plan.start_date.slice(0, 10) : '';
  return /^\d{4}-\d{2}-\d{2}$/.test(start) && start < todayInDhaka();
};

// Plans created before `status` existed have none (or ''); treat that as open.
// isOpen and OPEN_STATUS must agree: one is the pre-check, the other the
// condition of the atomic seat reservation.
const OPEN_STATUS = { $in: ['open', null, ''] };
const isOpen = (plan) => plan.status == null || plan.status === '' || plan.status === 'open';

// A pending booking whose seats are held but not yet paid for: never paid,
// payment submitted and awaiting verification, or payment rejected. All of
// these count toward the per-user limits on outstanding bookings.
const AWAITING_PAYMENT = ['unpaid', 'pending_verification', 'failed'];
// Of those, the ones whose seat hold can run out (a submitted payment is
// waiting on the admin, so it never expires on its own).
const EXPIRABLE_PAYMENT = ['unpaid', 'failed'];

const newHoldExpiry = (from = new Date()) => new Date(from.getTime() + HOLD_MINUTES * 60 * 1000).toISOString();

const canView = (req, booking) => req.user.role === 'admin' || String(booking.userId) === String(req.user.userId);

// Shared by the request handlers and the periodic sweep started in index.js.
const createHoldHelpers = ({ BookingCollection, TravelPlanCollection, CouponCollection }) => {
  // Give seats back to the plan, reopening it if it had been marked full.
  const releaseSeats = async (planId, count) => {
    await TravelPlanCollection.updateOne(
      { _id: planId, seats_available: { $type: 'number' } },
      { $inc: { seats_available: count } }
    );
    await TravelPlanCollection.updateOne(
      { _id: planId, status: 'full', seats_available: { $gt: 0 } },
      { $set: { status: 'open' } }
    );
  };

  // Give back the coupon use a cancelled booking had taken.
  const releaseCoupon = async (booking) => {
    if (!booking.coupon?.couponId) return;
    await CouponCollection.updateOne({ _id: booking.coupon.couponId, usedCount: { $gt: 0 } }, { $inc: { usedCount: -1 } });
  };

  // An unpaid (or payment-rejected) pending booking whose hold has run out.
  // Bookings created before holds existed have no holdExpiresAt and never match.
  const expiredHoldFilter = (now) => ({
    paymentStatus: { $in: EXPIRABLE_PAYMENT },
    bookingStatus: 'pending',
    holdExpiresAt: { $exists: true, $lt: now },
  });

  // Cancel one expired hold. The conditional update means only one caller can
  // win, so seats are released exactly once even if sweeps run concurrently.
  const expireHold = async (booking, now) => {
    const result = await BookingCollection.updateOne(
      { _id: booking._id, ...expiredHoldFilter(now) },
      {
        $set: { bookingStatus: 'cancelled', cancelReason: 'expired' },
        $push: { statusHistory: historyEntry('cancelled', 'Payment hold expired') },
        $unset: { holdExpiresAt: '' },
      }
    );
    if (result.modifiedCount === 1) {
      await releaseSeats(booking.planId, booking.ticketCount);
      await releaseCoupon(booking);
      return true;
    }
    return false;
  };

  // Expire every overdue hold (optionally only for one plan). Returns how many were expired.
  const sweepExpiredHolds = async (planId) => {
    const now = new Date().toISOString();
    const filter = expiredHoldFilter(now);
    if (planId) filter.planId = planId;
    const expired = await BookingCollection.find(filter, {
      projection: {
        _id: 1, planId: 1, ticketCount: 1, coupon: 1, userId: 1, userName: 1, userEmail: 1, referenceCode: 1,
        planTitle_en: 1, planTitle_bn: 1, planSlug: 1, start_date: 1, end_date: 1, totalAmount: 1,
      },
    }).toArray();
    let count = 0;
    for (const booking of expired) {
      if (await expireHold(booking, now)) {
        count++;
        bookingHoldExpired(booking);
        notices.holdExpired(booking);
      }
    }
    return count;
  };

  return { releaseSeats, releaseCoupon, expireHold, sweepExpiredHolds };
};

module.exports = (collections) => {
  const { BookingCollection, TravelPlanCollection, PaymentMethodCollection, CouponCollection, OrderCollection } = collections;
  const { releaseSeats, releaseCoupon, expireHold, sweepExpiredHolds } = createHoldHelpers(collections);

  return {
    sweepExpiredHolds,

    createBooking: async (req, res) => {
      try {
        const { note } = req.body;
        const planSlug = req.body.planSlug == null || typeof req.body.planSlug === 'object' ? '' : String(req.body.planSlug).trim();
        if (!planSlug) return res.status(400).json({ success: false, message: 'Select a travel plan' });
        const ticketCount = Number(req.body.ticketCount);

        if (!Number.isInteger(ticketCount) || ticketCount < 1 || ticketCount > MAX_TICKETS) {
          return res.status(400).json({ success: false, message: `You can book 1 to ${MAX_TICKETS} tickets at a time` });
        }
        const { travellers, error } = validateTravellers(req.body.travellers, ticketCount);
        if (error) return res.status(400).json({ success: false, message: error });

        const plan = await TravelPlanCollection.findOne({ slug: planSlug });
        if (!plan) return res.status(404).json({ success: false, message: 'Travel plan not found' });
        if (!isOpen(plan)) {
          return res.status(409).json({ success: false, message: 'Booking is not open for this plan' });
        }
        if (hasStarted(plan)) {
          return res.status(409).json({ success: false, message: 'This trip has already started' });
        }
        if (!(plan.price > 0)) {
          return res.status(409).json({ success: false, message: 'This plan is not available for online booking yet' });
        }

        // Free seats held by expired unpaid bookings before checking availability.
        await sweepExpiredHolds(plan._id);

        const userId = new ObjectId(req.user.userId);
        const outstanding = { userId, paymentStatus: { $in: AWAITING_PAYMENT }, bookingStatus: 'pending' };
        // Returns the 409 message when the user is over a limit, else null.
        const overLimit = async (allowed) => {
          const [forPlan, total] = await Promise.all([
            BookingCollection.countDocuments({ ...outstanding, planId: plan._id }),
            BookingCollection.countDocuments(outstanding),
          ]);
          if (forPlan > allowed.perPlan) return 'You already have a booking for this plan that is awaiting payment or verification — complete it first';
          if (total > allowed.total) return `You have ${MAX_UNPAID_TOTAL} bookings awaiting payment or verification — complete them or wait for them to expire before booking again`;
          return null;
        };
        const limitError = await overLimit({ perPlan: MAX_UNPAID_PER_PLAN - 1, total: MAX_UNPAID_TOTAL - 1 });
        if (limitError) return res.status(409).json({ success: false, message: limitError });

        // Optional coupon: checked here, its use reserved after the seats.
        const subtotalAmount = plan.price * ticketCount;
        let coupon = null;
        let discountAmount = 0;
        const couponCode = normalizeCode(req.body.couponCode);
        if (couponCode) {
          coupon = COUPON_CODE.test(couponCode) ? await CouponCollection.findOne({ code: couponCode }) : null;
          const usesByUser = coupon ? await BookingCollection.countDocuments({
            userId, 'coupon.couponId': coupon._id, bookingStatus: { $ne: 'cancelled' },
          }) : 0;
          const problem = couponProblem(coupon, { planId: plan._id, subtotal: subtotalAmount, usesByUser });
          if (problem) return res.status(400).json({ success: false, message: problem });
          discountAmount = couponDiscount(coupon, subtotalAmount);
          if (discountAmount >= subtotalAmount) {
            return res.status(400).json({ success: false, message: 'This coupon cannot be used for online booking; please contact us' });
          }
        }

        // Generated before any seats are reserved, so a failure here cannot leak seats.
        const referenceCode = await generateUniqueReferenceCode(BookingCollection);

        // Reserve seats atomically so two bookings cannot take the same last seat.
        const hasSeatLimit = typeof plan.seats_available === 'number';
        if (hasSeatLimit) {
          const reserved = await TravelPlanCollection.updateOne(
            { _id: plan._id, status: OPEN_STATUS, seats_available: { $gte: ticketCount } },
            { $inc: { seats_available: -ticketCount } }
          );
          if (!reserved.modifiedCount) {
            const fresh = await TravelPlanCollection.findOne({ _id: plan._id });
            if (!fresh || !isOpen(fresh)) {
              return res.status(409).json({ success: false, message: 'Booking is not open for this plan' });
            }
            const left = fresh.seats_available ?? 0;
            return res.status(409).json({ success: false, message: left > 0 ? `Only ${left} seat${left === 1 ? '' : 's'} left` : 'This plan is fully booked' });
          }
          await TravelPlanCollection.updateOne({ _id: plan._id, seats_available: 0, status: OPEN_STATUS }, { $set: { status: 'full' } });
        }

        // Take one use of the coupon; the limit is enforced by the update itself.
        if (coupon) {
          const used = await CouponCollection.updateOne(
            {
              _id: coupon._id,
              active: { $ne: false },
              $or: [{ usageLimit: { $not: { $gt: 0 } } }, { $expr: { $lt: [{ $ifNull: ['$usedCount', 0] }, '$usageLimit'] } }],
            },
            { $inc: { usedCount: 1 } }
          );
          if (!used.modifiedCount) {
            if (hasSeatLimit) await releaseSeats(plan._id, ticketCount);
            return res.status(409).json({ success: false, message: 'This coupon has been fully used' });
          }
        }
        const couponInfo = coupon ? { couponId: coupon._id, code: coupon.code, discount: discountAmount } : null;

        const totalAmount = subtotalAmount - discountAmount;
        const advanceAmount = Math.ceil(totalAmount * ADVANCE_RATE);
        const createdAt = new Date();
        const now = createdAt.toISOString();
        const holdExpiresAt = newHoldExpiry(createdAt);

        const booking = {
          referenceCode,
          userId,
          userName: req.user.name || '',
          userEmail: req.user.email || '',
          planId: plan._id,
          planSlug: plan.slug,
          planTitle_bn: plan.title_bn,
          planTitle_en: plan.title_en,
          start_date: plan.start_date || '',
          end_date: plan.end_date || '',
          ticketCount,
          travellers,
          note: String(note || '').trim().slice(0, 1000),
          pricePerPerson: plan.price,
          subtotalAmount,
          discountAmount,
          coupon: couponInfo,
          totalAmount,
          advanceAmount,
          dueAmount: totalAmount,
          paidAmount: 0,
          paymentStatus: 'unpaid',
          bookingStatus: 'pending',
          payment: null,
          statusHistory: [historyEntry('pending', 'Booking created')],
          createdAt: now,
          holdExpiresAt,
        };

        let result;
        try {
          result = await BookingCollection.insertOne(booking);
        } catch (insertErr) {
          if (hasSeatLimit) await releaseSeats(plan._id, ticketCount);
          await releaseCoupon(booking);
          throw insertErr;
        }

        // The limit check above is count-then-insert, so parallel requests can
        // all pass it. Re-check now that this booking exists and undo it if the
        // user ended up over a limit.
        const raceError = await overLimit({ perPlan: MAX_UNPAID_PER_PLAN, total: MAX_UNPAID_TOTAL });
        if (raceError) {
          const removed = await BookingCollection.deleteOne({ _id: result.insertedId, paymentStatus: 'unpaid' });
          if (removed.deletedCount && hasSeatLimit) await releaseSeats(plan._id, ticketCount);
          if (removed.deletedCount) await releaseCoupon(booking);
          if (removed.deletedCount) return res.status(409).json({ success: false, message: raceError });
        }

        notices.bookingCreated({ ...booking, _id: result.insertedId });

        res.status(201).json({ success: true, bookingId: result.insertedId, referenceCode: booking.referenceCode, holdExpiresAt });
      } catch (err) {
        console.error('Create booking error:', err);
        res.status(500).json({ success: false, message: 'Internal server error' });
      }
    },

    getMyBookings: async (req, res) => {
      const result = await BookingCollection.find({ userId: new ObjectId(req.user.userId) }).sort({ _id: -1 }).toArray();
      res.json(result);
    },

    getBooking: async (req, res) => {
      // :id is the reference code (or, for older links, the database id).
      const filter = refOrIdFilter(req.params.id, toObjectId);
      if (!filter) return invalidId(res);
      const booking = await BookingCollection.findOne(filter);
      if (!booking || !canView(req, booking)) {
        return res.status(404).json({ success: false, message: 'Booking not found' });
      }
      res.json(booking);
    },

    // Customer reports the advance they sent by mobile banking; an admin verifies it later.
    submitPayment: async (req, res) => {
      try {
        const id = toObjectId(req.params.id);
        if (!id) return invalidId(res);
        const methodId = toObjectId(req.body.paymentMethodId);
        const senderNumber = String(req.body.senderNumber || '').replace(/[\s-]/g, '');
        const transactionId = String(req.body.transactionId || '').trim().toUpperCase();

        // Independent lookups run together (one round trip instead of three);
        // their results are still checked in the original order below.
        // A TrxID can pay for one booking or one shop order, never two.
        const [booking, method, reused, reusedByOrder] = await Promise.all([
          BookingCollection.findOne({ _id: id }),
          methodId ? PaymentMethodCollection.findOne({ _id: methodId, active: { $ne: false } }) : null,
          TRX_ID.test(transactionId)
            ? BookingCollection.findOne({ 'payment.transactionId': transactionId, _id: { $ne: id } }, { projection: { _id: 1 } })
            : null,
          TRX_ID.test(transactionId) && OrderCollection
            ? OrderCollection.findOne({ 'payment.transactionId': transactionId }, { projection: { _id: 1 } })
            : null,
        ]);
        if (!booking || String(booking.userId) !== String(req.user.userId)) {
          return res.status(404).json({ success: false, message: 'Booking not found' });
        }
        if (booking.bookingStatus === 'cancelled') {
          return res.status(409).json({ success: false, message: 'This booking was cancelled' });
        }
        if (!['unpaid', 'failed'].includes(booking.paymentStatus)) {
          return res.status(409).json({ success: false, message: 'Payment has already been submitted for this booking' });
        }
        const holdExpired = () => booking.holdExpiresAt && booking.holdExpiresAt < new Date().toISOString();
        if (holdExpired()) {
          await expireHold(booking, new Date().toISOString());
          return res.status(409).json({ success: false, message: 'Your seat hold expired; please book again' });
        }

        if (!method) return res.status(400).json({ success: false, message: 'Select a payment method' });

        if (!BD_PHONE.test(senderNumber)) {
          return res.status(400).json({ success: false, message: 'Enter the number you sent the money from' });
        }
        if (!TRX_ID.test(transactionId)) {
          return res.status(400).json({ success: false, message: 'Enter a valid transaction ID' });
        }
        if (reused || reusedByOrder) {
          return res.status(409).json({ success: false, message: 'This transaction ID has already been used' });
        }

        const payment = {
          methodId: method._id,
          method: method.method,
          number: method.number,
          senderNumber,
          transactionId,
          amount: booking.advanceAmount,
          submittedAt: new Date().toISOString(),
        };

        // The status filter makes a double submit a no-op instead of overwriting,
        // and also loses to a sweep that cancelled the booking in the meantime.
        // Removing holdExpiresAt means a booking awaiting verification never expires.
        const result = await BookingCollection.updateOne(
          {
            _id: id,
            paymentStatus: { $in: ['unpaid', 'failed'] },
            bookingStatus: { $ne: 'cancelled' },
            $or: [{ holdExpiresAt: { $exists: false } }, { holdExpiresAt: { $gte: new Date().toISOString() } }],
          },
          {
            $set: { payment, paymentStatus: 'pending_verification' },
            $push: { statusHistory: historyEntry('pending_verification', `${method.method} TrxID ${transactionId}`) },
            $unset: { holdExpiresAt: '' },
          }
        );
        if (!result.modifiedCount) {
          if (holdExpired()) {
            await expireHold(booking, new Date().toISOString());
            return res.status(409).json({ success: false, message: 'Your seat hold expired; please book again' });
          }
          return res.status(409).json({ success: false, message: 'Payment has already been submitted for this booking' });
        }
        notices.paymentSubmitted({ ...booking, payment, paymentStatus: 'pending_verification' });
        res.json({ success: true, message: 'Payment submitted for verification' });
      } catch (err) {
        console.error('Submit payment error:', err);
        res.status(500).json({ success: false, message: 'Internal server error' });
      }
    },

    // Admin list. Supports ?page&limit&q (see utils/pagination) plus
    // ?paymentStatus and ?bookingStatus filters (whitelisted values).
    getAllBookings: async (req, res) => {
      const filter = {};
      const { paymentStatus, bookingStatus } = req.query;
      if (paymentStatus !== undefined && paymentStatus !== '') {
        if (!PAYMENT_STATUSES.includes(paymentStatus)) {
          return res.status(400).json({ success: false, message: 'Invalid payment status' });
        }
        filter.paymentStatus = paymentStatus;
      }
      if (bookingStatus !== undefined && bookingStatus !== '') {
        if (!BOOKING_STATUSES.includes(bookingStatus)) {
          return res.status(400).json({ success: false, message: 'Invalid booking status' });
        }
        filter.bookingStatus = bookingStatus;
      }
      await sendList(req, res, BookingCollection, { filter, searchFields: BOOKING_SEARCH_FIELDS });
    },

    updatePaymentStatus: async (req, res) => {
      try {
        const id = toObjectId(req.params.id);
        if (!id) return invalidId(res);
        const { paymentStatus } = req.body || {};
        if (!PAYMENT_STATUSES.includes(paymentStatus)) {
          return res.status(400).json({ success: false, message: 'Invalid payment status' });
        }
        const booking = await BookingCollection.findOne({ _id: id });
        if (!booking) return res.status(404).json({ success: false, message: 'Booking not found' });

        const paidAmount = paymentStatus === 'paid_full' ? booking.totalAmount
          : paymentStatus === 'advance_paid' ? booking.advanceAmount
          : 0;
        const update = { paymentStatus, paidAmount, dueAmount: booking.totalAmount - paidAmount };
        const unset = {};
        if (['advance_paid', 'paid_full'].includes(paymentStatus) && booking.bookingStatus === 'pending') {
          update.bookingStatus = 'confirmed';
        }
        // A pending booking sent back to unpaid/failed (payment rejected) gets a
        // fresh hold: the traveller can pay again, and if they don't, the sweep
        // releases the seats. Any other status ends the hold.
        if (EXPIRABLE_PAYMENT.includes(paymentStatus) && booking.bookingStatus === 'pending') {
          update.holdExpiresAt = newHoldExpiry();
        } else {
          unset.holdExpiresAt = '';
        }

        // Conditional on the state we read, so this cannot undo a change made in
        // the meantime (e.g. the hold sweep cancelling the booking and releasing
        // its seats just before an admin confirms it).
        const result = await BookingCollection.updateOne(
          { _id: id, bookingStatus: booking.bookingStatus, paymentStatus: booking.paymentStatus },
          {
            $set: update,
            ...(Object.keys(unset).length ? { $unset: unset } : {}),
            $push: { statusHistory: historyEntry(paymentStatus, 'Payment status updated by admin') },
          }
        );
        if (!result.matchedCount) {
          return res.status(409).json({ success: false, message: 'This booking changed while you were editing it. Reload and try again.' });
        }
        const updated = await BookingCollection.findOne({ _id: id });
        if (updated) notices.paymentStatusChanged(updated, booking);
        res.json({ success: true, booking: updated });
      } catch (err) {
        console.error('Update payment status error:', err);
        res.status(500).json({ success: false, message: 'Error updating payment status' });
      }
    },

    updateBookingStatus: async (req, res) => {
      try {
        const id = toObjectId(req.params.id);
        if (!id) return invalidId(res);
        const { status } = req.body || {};
        if (!BOOKING_STATUSES.includes(status)) {
          return res.status(400).json({ success: false, message: 'Invalid booking status' });
        }
        const booking = await BookingCollection.findOne({ _id: id });
        if (!booking) return res.status(404).json({ success: false, message: 'Booking not found' });
        const reopenError = () => res.status(409).json({ success: false, message: 'A cancelled booking cannot be reopened; ask the traveller to book again' });
        if (booking.bookingStatus === 'cancelled' && status !== 'cancelled') return reopenError();

        // Conditional on "not cancelled yet": of two concurrent cancels (or a
        // cancel racing the hold sweep) only one modifies the document, and only
        // that one releases the seats. The same condition stops a status change
        // from reopening a booking that was cancelled after we read it.
        const result = await BookingCollection.updateOne(
          { _id: id, bookingStatus: { $ne: 'cancelled' } },
          {
            $set: { bookingStatus: status },
            $push: { statusHistory: historyEntry(status, 'Booking status updated by admin') },
            ...(status === 'cancelled' ? { $unset: { holdExpiresAt: '' } } : {}),
          }
        );
        if (result.modifiedCount === 1) {
          if (status === 'cancelled') {
            await releaseSeats(booking.planId, booking.ticketCount);
            await releaseCoupon(booking);
          }
        } else if (status !== 'cancelled') {
          // Cancelled between our read and the update.
          return reopenError();
        }
        // Cancelling an already-cancelled booking is an idempotent no-op.
        const updated = await BookingCollection.findOne({ _id: id });
        if (updated && result.modifiedCount === 1) notices.bookingStatusChanged(updated, booking.bookingStatus);
        res.json({ success: true, booking: updated });
      } catch (err) {
        console.error('Update booking status error:', err);
        res.status(500).json({ success: false, message: 'Error updating booking status' });
      }
    },
  };
};

module.exports.createHoldHelpers = createHoldHelpers;
module.exports.HOLD_MINUTES = HOLD_MINUTES;
